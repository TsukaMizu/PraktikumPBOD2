package Array;


class QueueOfNumber extends Queue{
    public QueueOfNumber(){

    }

    public boolean cekElmtType(Object elmt){
        return (elmt instanceof Integer);
    }
}
